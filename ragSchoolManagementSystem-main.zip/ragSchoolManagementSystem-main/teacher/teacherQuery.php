<?php
require_once "../PDODB/DBh.php";
class TeacherQuery extends DBh{
    public function bro(){
        echo "echo";
    }
}

?>