<?php
echo "Yess";
 
  require "../teacherQuery.php";
  $query = new TeacherQuery();
  $query->bro();
?>